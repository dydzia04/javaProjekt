create definer = root@localhost view new_view as
select `mydb`.`Employees`.`firstName`      AS `Imię`,
       `mydb`.`Employees`.`surName`        AS `Nazwisko`,
       `mydb`.`Jobs`.`name`                AS `Pozycja`,
       `mydb`.`Jobs`.`baseSalary`          AS `Zarobki`,
       `mydb`.`Departaments`.`address`     AS `Miejsce pracy`,
       `mydb`.`Departaments`.`phoneNumber` AS `Numer do miejsca pracy`,
       `mydb`.`Departaments`.`eMail`       AS `e-mail do miejsca pracy`
from ((`mydb`.`Employees` join `mydb`.`Departaments` on ((`mydb`.`Employees`.`idDept` = `mydb`.`Departaments`.`idDepartaments`)))
         join `mydb`.`Jobs` on ((`mydb`.`Employees`.`idJob` = `mydb`.`Jobs`.`idJobs`)));

